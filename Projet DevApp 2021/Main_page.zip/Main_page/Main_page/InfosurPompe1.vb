﻿Public Class InfosurPompe1
    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles TextBox1.TextChanged

    End Sub

    Private Sub InfosurPompe1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class