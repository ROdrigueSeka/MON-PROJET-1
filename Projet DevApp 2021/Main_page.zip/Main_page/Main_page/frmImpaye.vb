﻿Public Class frmImpaye
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click

    End Sub

    Private Sub GroupBox1_Enter(sender As Object, e As EventArgs) Handles GroupBox1.Enter

    End Sub

    Private Sub frmImpaye_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class